package org.ganjp.extend.ant;

public abstract class BaseTask {
	
	public abstract void execute() throws Exception;

}
