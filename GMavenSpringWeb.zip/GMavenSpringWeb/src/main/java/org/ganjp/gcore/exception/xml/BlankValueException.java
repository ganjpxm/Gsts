/*
 * $Id: BlankValueException.java,v 1.1 2011/04/02 10:32:17 ganjp Exp $
 *
 * Copyright (c) 2010 ChinaSoft International, Ltd. All rights reserved
 * ResourceOne BizFoundation Project
 *
 */
package org.ganjp.gcore.exception.xml;

/**
 * @author Administrator
 */
public class BlankValueException extends Exception {

	/**
	 * 
	 */
	public BlankValueException() {
		super();

	}

	/**
	 * @param s
	 */
	public BlankValueException(String s) {
		super(s);

	}

}
