/*
 * $Id: ChildNotFoundException.java,v 1.1 2011/04/02 10:32:17 ganjp Exp $
 *
 * Copyright (c) 2010 ChinaSoft International, Ltd. All rights reserved
 * ResourceOne BizFoundation Project
 *
 */
package org.ganjp.gcore.exception.xml;

/**
 * @author Administrator
 */
public class ChildNotFoundException extends Exception {

	/**
	 * 
	 */
	public ChildNotFoundException() {
		super();

	}

	/**
	 * @param s
	 */
	public ChildNotFoundException(String s) {
		super(s);

	}

}
