package org.ganjp.gone.common.dao;

import java.io.Serializable;

public interface GenericDao<T extends Serializable> extends Operations<T> {
	
}
